<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Forward</label>
    <protected>false</protected>
    <values>
        <field>ZP_Action__c</field>
        <value xsi:type="xsd:string">Forward</value>
    </values>
    <values>
        <field>ZP_Active__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>ZP_Component__c</field>
        <value xsi:type="xsd:string">ZP_DocViewerEventNotifier</value>
    </values>
    <values>
        <field>ZP_Document_Record_Type__c</field>
        <value xsi:type="xsd:string">ALL</value>
    </values>
    <values>
        <field>ZP_Icon_Name__c</field>
        <value xsi:type="xsd:string">action:share</value>
    </values>
    <values>
        <field>ZP_Ordinal__c</field>
        <value xsi:type="xsd:double">4.0</value>
    </values>
    <values>
        <field>ZP_Tooltip__c</field>
        <value xsi:type="xsd:string">Attach pages to current record</value>
    </values>
</CustomMetadata>
